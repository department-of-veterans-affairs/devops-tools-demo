import os

WCT_SECRET_SAUCE = os.getenv('SECRET_SAUCE')
PATH_TO_DATA_FILE = os.getenv('PATH_TO_DATA_FILE')
WCT_VERSION = os.getenv('WCT_VERSION')
